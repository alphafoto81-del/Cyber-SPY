package com.mrcourses.disciplined100

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidWidgetBridge(this), "AndroidWidget")
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class AndroidWidgetBridge(private val activity: Activity) {
    @JavascriptInterface
    fun updateSummary(json: String) {
        try {
            val obj = JSONObject(json)
            val prefs = activity.getSharedPreferences(WidgetProvider.PREFS, Activity.MODE_PRIVATE)
            prefs.edit()
                .putString("date", obj.optString("date", ""))
                .putString("time", obj.optString("time", "--:--"))
                .putString("task", obj.optString("task", "افتح التطبيق لمزامنة المهمة"))
                .putInt("day", obj.optInt("day", 0))
                .putInt("intake", obj.optInt("intake", 0))
                .putInt("out", obj.optInt("out", 0))
                .putInt("balance", obj.optInt("balance", 0))
                .putString("balanceLabel", obj.optString("balanceLabel", "تقديري"))
                .putInt("progress", obj.optInt("progress", 0))
                .putFloat("weight", obj.optDouble("weight", 90.0).toFloat())
                .apply()
            activity.runOnUiThread { WidgetProvider.updateAll(activity) }
        } catch (_: Exception) {
            // Ignore malformed summaries rather than interrupting the main web app.
        }
    }
}
