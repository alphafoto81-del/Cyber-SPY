package com.mrcourses.disciplined100

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        const val PREFS = "disciplined100_widget"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget_summary)
            val day = prefs.getInt("day", 0)
            views.setTextViewText(R.id.widgetDay, if (day in 1..100) "اليوم $day / 100" else "مئة يوم منضبطة")
            views.setTextViewText(R.id.widgetTime, prefs.getString("time", "--:--"))
            views.setTextViewText(R.id.widgetTask, prefs.getString("task", "افتح التطبيق لمزامنة المهمة"))
            views.setTextViewText(R.id.widgetCaloriesIn, "${prefs.getInt("intake", 0)}")
            views.setTextViewText(R.id.widgetCaloriesOut, "${prefs.getInt("out", 0)}")
            views.setTextViewText(R.id.widgetBalance, "${prefs.getInt("balance", 0)} · ${prefs.getString("balanceLabel", "تقديري")}")
            views.setProgressBar(R.id.widgetProgress, 100, prefs.getInt("progress", 0).coerceIn(0, 100), false)
            val intent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(context, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widgetRoot, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
